from flask import Flask, render_template, request, redirect, flash
from sistema import SistemaConsorcio

app = Flask(__name__)

app.secret_key = "consorcio"

sistema = SistemaConsorcio()


# ==========================================
# MENU PRINCIPAL
# ==========================================

@app.route("/")
def index():

    return render_template(
        "menu_principal.html",
        estatisticas=sistema.estatisticas_sistema()
    )


# ==========================================
# CLIENTES
# ==========================================

@app.route("/clientes")
def clientes():

    return render_template(
        "clientes.html",
        clientes=sistema.listar_clientes(),
        grupos=sistema.listar_grupos()
    )


@app.route("/cadastrar_cliente", methods=["POST"])
def cadastrar_cliente():

    try:

        sistema.cadastrar_cliente(
            request.form["nome"],
            request.form["cpf"],
            request.form["telefone"],
            request.form["email"],
            int(request.form["grupo_id"])
        )

        flash("✅ Cliente cadastrado com sucesso")

    except Exception as erro:

        flash(f"❌ {erro}")

    return redirect("/clientes")


# ==========================================
# VEICULOS
# ==========================================

@app.route("/veiculos")
def veiculos():

    return render_template(
        "veiculos.html",
        veiculos=sistema.listar_veiculos()
    )


@app.route("/cadastrar_veiculo", methods=["POST"])
def cadastrar_veiculo():

    sistema.cadastrar_veiculo(
        request.form["marca"],
        request.form["modelo"],
        int(request.form["ano"]),
        float(request.form["valor"])
    )

    flash("✅ Veículo cadastrado com sucesso")

    return redirect("/veiculos")


# ==========================================
# GRUPOS
# ==========================================

@app.route("/grupos")
def grupos():

    return render_template(
        "grupos.html",
        grupos=sistema.listar_grupos(),
        veiculos=sistema.listar_veiculos()
    )


@app.route("/criar_grupo", methods=["POST"])
def criar_grupo():

    sistema.criar_grupo(
        request.form["nome"],
        int(request.form["veiculo_id"]),
        int(request.form["quantidade_cotas"]),
        int(request.form["prazo_meses"])
    )

    flash("✅ Grupo criado com sucesso")

    return redirect("/grupos")


# ==========================================
# COTAS
# ==========================================

@app.route("/cotas")
def cotas():

    cotas_detalhadas = []

    for cota in sistema.listar_cotas():

        cliente = sistema.buscar_cliente(
            cota.cliente_id
        )

        grupo = sistema.buscar_grupo(
            cota.grupo_id
        )

        cotas_detalhadas.append({

            "id": cota.id,
            "numero": cota.numero,

            "cliente":
            cliente.nome if cliente
            else "Não encontrado",

            "grupo":
            grupo.nome if grupo
            else "Não encontrado",

            "status": cota.status.value,

            "parcelas":
            len(cota.parcelas),

            "total_pago":
            cota.total_pago()

        })

    return render_template(
        "cotas.html",
        clientes=sistema.listar_clientes(),
        grupos=sistema.listar_grupos(),
        cotas=cotas_detalhadas
    )


@app.route("/vender_cota", methods=["POST"])
def vender_cota():

    sistema.vender_cota(
        int(request.form["cliente_id"]),
        int(request.form["grupo_id"])
    )

    flash("✅ Cota vendida com sucesso")

    return redirect("/cotas")


# ==========================================
# MAIN
# ==========================================

if __name__ == "__main__":

    app.run(debug=True)