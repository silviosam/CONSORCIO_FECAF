from dataclasses import dataclass
from enum import Enum
from typing import Dict, List
import re


# ==========================================
# FORMATADOR
# ==========================================

def formatar_moeda(valor):

    return f"R$ {valor:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


# ==========================================
# VALIDADORES
# ==========================================

def validar_email(email):

    padrao = r'^[\w\.-]+@[\w\.-]+\.\w+$'

    return re.match(padrao, email)


def validar_telefone(telefone):

    padrao = r'^\(\d{2}\)\s\d{4,5}-\d{4}$'

    return re.match(padrao, telefone)


def validar_cpf(cpf):

    cpf = re.sub(r'[^0-9]', '', cpf)

    if len(cpf) != 11:
        return False

    if cpf == cpf[0] * 11:
        return False

    soma = 0

    for i in range(9):
        soma += int(cpf[i]) * (10 - i)

    digito1 = (soma * 10 % 11) % 10

    soma = 0

    for i in range(10):
        soma += int(cpf[i]) * (11 - i)

    digito2 = (soma * 10 % 11) % 10

    return digito1 == int(cpf[9]) and digito2 == int(cpf[10])


# ==========================================
# STATUS
# ==========================================

class StatusCota(Enum):

    ATIVA = "Ativa"
    CONTEMPLADA = "Contemplada"
    CANCELADA = "Cancelada"


# ==========================================
# CLASSES
# ==========================================

@dataclass
class Cliente:

    id: int
    nome: str
    cpf: str
    telefone: str
    email: str
    grupo_id: int


@dataclass
class Veiculo:

    id: int
    marca: str
    modelo: str
    ano: int
    valor: float


@dataclass
class Grupo:

    id: int
    nome: str
    parcelas: int
    valor_credito: float
    quantidade_cotas: int
    taxa: float


@dataclass
class Parcela:

    numero: int
    valor: float
    paga: bool = False

    def pagar(self):

        self.paga = True


@dataclass
class Cota:

    id: int
    numero: int
    cliente_id: int
    grupo_id: int
    parcelas: List[Parcela]
    status: StatusCota = StatusCota.ATIVA
    lance_ofertado: float = 0.0

    def total_pago(self):

        return sum(
            p.valor
            for p in self.parcelas
            if p.paga
        )


# ==========================================
# SISTEMA
# ==========================================

class SistemaConsorcio:

    def __init__(self):

        self.clientes: Dict[int, Cliente] = {}
        self.veiculos: Dict[int, Veiculo] = {}
        self.grupos: Dict[int, Grupo] = {}
        self.cotas: Dict[int, Cota] = {}

        self.id_cliente = 1
        self.id_veiculo = 1
        self.id_grupo = 1
        self.id_cota = 1


    # ==========================================
    # CLIENTES
    # ==========================================

    def cadastrar_cliente(
        self,
        nome,
        cpf,
        telefone,
        email,
        grupo_id
    ):

        if not validar_cpf(cpf):
            raise ValueError("CPF inválido")

        if not validar_telefone(telefone):
            raise ValueError("Telefone inválido")

        if not validar_email(email):
            raise ValueError("E-mail inválido")

        cliente = Cliente(
            self.id_cliente,
            nome,
            cpf,
            telefone,
            email,
            grupo_id
        )

        self.clientes[self.id_cliente] = cliente

        self.id_cliente += 1

        return cliente


    def listar_clientes(self):

        return list(self.clientes.values())


    def buscar_cliente(self, cliente_id):

        return self.clientes.get(cliente_id)


    # ==========================================
    # VEICULOS
    # ==========================================

    def cadastrar_veiculo(
        self,
        marca,
        modelo,
        ano,
        valor
    ):

        veiculo = Veiculo(
            self.id_veiculo,
            marca,
            modelo,
            ano,
            valor
        )

        self.veiculos[self.id_veiculo] = veiculo

        self.id_veiculo += 1

        return veiculo


    def listar_veiculos(self):

        return list(self.veiculos.values())


    # ==========================================
    # GRUPOS
    # ==========================================

    def criar_grupo(
        self,
        nome,
        veiculo_id,
        quantidade_cotas,
        prazo_meses
    ):

        veiculo = self.veiculos[veiculo_id]

        if prazo_meses <= 36:
            taxa = 10

        elif prazo_meses <= 60:
            taxa = 15

        elif prazo_meses <= 80:
            taxa = 18

        elif prazo_meses <= 100:
            taxa = 22

        else:
            taxa = 25

        valor_credito = veiculo.valor + (
            veiculo.valor * (taxa / 100)
        )

        grupo = Grupo(
            self.id_grupo,
            nome,
            prazo_meses,
            valor_credito,
            quantidade_cotas,
            taxa
        )

        self.grupos[self.id_grupo] = grupo

        self.id_grupo += 1

        return grupo


    def listar_grupos(self):

        return list(self.grupos.values())


    def buscar_grupo(self, grupo_id):

        return self.grupos.get(grupo_id)


    # ==========================================
    # COTAS
    # ==========================================

    def vender_cota(
        self,
        cliente_id,
        grupo_id
    ):

        grupo = self.grupos[grupo_id]

        valor_parcela = (
            grupo.valor_credito /
            grupo.parcelas
        )

        parcelas = []

        for i in range(grupo.parcelas):

            parcelas.append(
                Parcela(
                    numero=i + 1,
                    valor=valor_parcela
                )
            )

        cota = Cota(
            id=self.id_cota,
            numero=self.id_cota,
            cliente_id=cliente_id,
            grupo_id=grupo_id,
            parcelas=parcelas
        )

        self.cotas[self.id_cota] = cota

        self.id_cota += 1

        return cota


    def listar_cotas(self):

        return list(self.cotas.values())


    # ==========================================
    # ESTATISTICAS
    # ==========================================

    def estatisticas_sistema(self):

        total_arrecadado = sum(
            c.total_pago()
            for c in self.cotas.values()
        )

        return {
            "clientes": len(self.clientes),
            "veiculos": len(self.veiculos),
            "grupos": len(self.grupos),
            "cotas": len(self.cotas),
            "arrecadado": formatar_moeda(total_arrecadado)
        }