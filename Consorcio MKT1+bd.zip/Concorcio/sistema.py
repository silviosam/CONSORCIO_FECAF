from dataclasses import dataclass
from enum import Enum
from typing import Dict, List
import re
import sqlite3

DB_NAME = "consorcio.db"

def conectar():
    return sqlite3.connect(DB_NAME)

def criar_banco():
    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS clientes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT,
        cpf TEXT,
        telefone TEXT,
        email TEXT,
        grupo_id INTEGER
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS veiculos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        marca TEXT,
        modelo TEXT,
        ano INTEGER,
        valor REAL
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS grupos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT,
        parcelas INTEGER,
        valor_credito REAL,
        quantidade_cotas INTEGER,
        taxa REAL
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS cotas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        numero INTEGER,
        cliente_id INTEGER,
        grupo_id INTEGER,
        lance_ofertado REAL
    )
    """)

    conn.commit()
    conn.close()

#Validadores
def validar_email(email):
    padrao = r'^[\w\.-]+@[\w\.-]+\.\w+$'
    return re.match(padrao, email)

def validar_telefone(telefone):
    padrao = r'^\(\d{2}\)\s\d{4,5}-\d{4}$'
    return re.match(padrao, telefone)

def validar_cpf(cpf):
    cpf = re.sub(r'[^0-9]', '', cpf)
    if len(cpf) != 11:
        return False
    if cpf == cpf[0] * 11:
        return False

    soma = 0
    for i in range(9):
        soma += int(cpf[i]) * (10 - i)

    digito1 = (soma * 10 % 11) % 10

    soma = 0
    for i in range(10):
        soma += int(cpf[i]) * (11 - i)

    digito2 = (soma * 10 % 11) % 10

    return digito1 == int(cpf[9]) and digito2 == int(cpf[10])

@dataclass
class Cliente:
    id: int
    nome: str
    cpf: str
    telefone: str
    email: str
    grupo_id: int

@dataclass
class Veiculo:
    id: int
    marca: str
    modelo: str
    ano: int
    valor: float

@dataclass
class Grupo:
    id: int
    nome: str
    parcelas: int
    valor_credito: float
    quantidade_cotas: int
    taxa: float

@dataclass
class Cota:
    id: int
    numero: int
    cliente_id: int
    grupo_id: int
    lance_ofertado: float = 0.0

class SistemaConsorcio:

    def __init__(self):
        criar_banco()

    # CLIENTES
    def cadastrar_cliente(self, nome, cpf, telefone, email, grupo_id):

        if not validar_cpf(cpf):
            raise ValueError("CPF inválido")

        if not validar_telefone(telefone):
            raise ValueError("Telefone inválido")

        if not validar_email(email):
            raise ValueError("E-mail inválido")

        conn = conectar()
        cursor = conn.cursor()

        cursor.execute("""
        INSERT INTO clientes (nome, cpf, telefone, email, grupo_id)
        VALUES (?, ?, ?, ?, ?)
        """, (nome, cpf, telefone, email, grupo_id))

        conn.commit()
        conn.close()

    def listar_clientes(self):
        conn = conectar()
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM clientes")
        dados = cursor.fetchall()

        conn.close()

        return [
            Cliente(*item) for item in dados
        ]

    # VEICULOS
    def cadastrar_veiculo(self, marca, modelo, ano, valor):

        conn = conectar()
        cursor = conn.cursor()

        cursor.execute("""
        INSERT INTO veiculos (marca, modelo, ano, valor)
        VALUES (?, ?, ?, ?)
        """, (marca, modelo, ano, valor))

        conn.commit()
        conn.close()

    def listar_veiculos(self):
        conn = conectar()
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM veiculos")
        dados = cursor.fetchall()

        conn.close()

        return [
            Veiculo(*item) for item in dados
        ]

    # GRUPOS
    def cadastrar_grupo(self, nome, parcelas, valor_credito, quantidade_cotas, taxa):

        conn = conectar()
        cursor = conn.cursor()

        cursor.execute("""
        INSERT INTO grupos (nome, parcelas, valor_credito, quantidade_cotas, taxa)
        VALUES (?, ?, ?, ?, ?)
        """, (nome, parcelas, valor_credito, quantidade_cotas, taxa))

        conn.commit()
        conn.close()

    def listar_grupos(self):
        conn = conectar()
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM grupos")
        dados = cursor.fetchall()

        conn.close()

        return [
            Grupo(*item) for item in dados
        ]

    # COTAS
    def cadastrar_cota(self, numero, cliente_id, grupo_id, lance_ofertado=0):

        conn = conectar()
        cursor = conn.cursor()

        cursor.execute("""
        INSERT INTO cotas (numero, cliente_id, grupo_id, lance_ofertado)
        VALUES (?, ?, ?, ?)
        """, (numero, cliente_id, grupo_id, lance_ofertado))

        conn.commit()
        conn.close()

    def listar_cotas(self):
        conn = conectar()
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM cotas")
        dados = cursor.fetchall()

        conn.close()

        return [
            Cota(*item) for item in dados
        ]

    def estatisticas_sistema(self):
        return {
            "clientes": len(self.listar_clientes()),
            "veiculos": len(self.listar_veiculos()),
            "grupos": len(self.listar_grupos()),
            "cotas": len(self.listar_cotas())
        }


    # EXCLUIR CLIENTE
    def excluir_cliente(self, id):
        conn = conectar()
        cursor = conn.cursor()

        cursor.execute("DELETE FROM clientes WHERE id = ?", (id,))

        conn.commit()
        conn.close()

    # EXCLUIR VEÍCULO
    def excluir_veiculo(self, id):
        conn = conectar()
        cursor = conn.cursor()

        cursor.execute("DELETE FROM veiculos WHERE id = ?", (id,))

        conn.commit()
        conn.close()

    # EXCLUIR GRUPO
    def excluir_grupo(self, id):
        conn = conectar()
        cursor = conn.cursor()

        cursor.execute("DELETE FROM grupos WHERE id = ?", (id,))

        conn.commit()
        conn.close()

    # EXCLUIR COTA
    def excluir_cota(self, id):
        conn = conectar()
        cursor = conn.cursor()

        cursor.execute("DELETE FROM cotas WHERE id = ?", (id,))

        conn.commit()
        conn.close()
