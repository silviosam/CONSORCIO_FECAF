from flask import Flask, render_template, request, redirect
from sistema import SistemaConsorcio

app = Flask(__name__)

sistema = SistemaConsorcio()



# PÁGINA INICIAL
@app.route("/")
def index():

    estatisticas = sistema.estatisticas_sistema()

    return render_template(
        "index.html",
        estatisticas=estatisticas
    )



# CLIENTES
@app.route("/clientes")
def clientes():

    return render_template(
        "clientes.html",
        clientes=sistema.listar_clientes()
    )


@app.route("/cadastrar_cliente", methods=["POST"])
def cadastrar_cliente():

    nome = request.form["nome"]
    cpf = request.form["cpf"]
    telefone = request.form["telefone"]
    email = request.form["email"]

    sistema.cadastrar_cliente(
        nome,
        cpf,
        telefone,
        email
    )

    return redirect("/clientes")



# VEÍCULOS
@app.route("/veiculos")
def veiculos():

    return render_template(
        "veiculos.html",
        veiculos=sistema.listar_veiculos()
    )


@app.route("/cadastrar_veiculo", methods=["POST"])
def cadastrar_veiculo():

    marca = request.form["marca"]
    modelo = request.form["modelo"]
    ano = int(request.form["ano"])
    valor = float(request.form["valor"])

    sistema.cadastrar_veiculo(
        marca,
        modelo,
        ano,
        valor
    )

    return redirect("/veiculos")



# GRUPOS
@app.route("/grupos")
def grupos():

    return render_template(
        "grupos.html",
        grupos=sistema.listar_grupos(),
        veiculos=sistema.listar_veiculos()
    )


@app.route("/criar_grupo", methods=["POST"])
def criar_grupo():

    nome = request.form["nome"]
    veiculo_id = int(request.form["veiculo_id"])
    quantidade_cotas = int(request.form["quantidade_cotas"])
    prazo_meses = int(request.form["prazo_meses"])
    taxa = float(request.form["taxa"])

    sistema.criar_grupo(
        nome,
        veiculo_id,
        quantidade_cotas,
        prazo_meses,
        taxa
    )

    return redirect("/grupos")



# COTAS
@app.route("/cotas")
def cotas():

    return render_template(
        "cotas.html",
        clientes=sistema.listar_clientes(),
        grupos=sistema.listar_grupos(),
        cotas=sistema.listar_cotas()
    )


@app.route("/vender_cota", methods=["POST"])
def vender_cota():

    cliente_id = int(request.form["cliente_id"])
    grupo_id = int(request.form["grupo_id"])

    sistema.vender_cota(
        cliente_id,
        grupo_id
    )

    return redirect("/cotas")



# Main
if __name__ == "__main__":
    app.run(debug=True)