from dataclasses import dataclass
from enum import Enum
from typing import Dict, List


def formatar_moeda(valor):
    return f"R$ {valor:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


class StatusCota(Enum):
    ATIVA = "Ativa"
    CONTEMPLADA = "Contemplada"
    CANCELADA = "Cancelada"


@dataclass
class Cliente:
    id: int
    nome: str
    cpf: str
    telefone: str
    email: str


@dataclass
class Veiculo:
    id: int
    marca: str
    modelo: str
    ano: int
    valor: float


@dataclass
class Grupo:
    id: int
    nome: str
    parcelas: int
    valor_credito: float
    quantidade_cotas: int
    taxa: float


@dataclass
class Parcela:
    numero: int
    valor: float
    paga: bool = False

    def pagar(self):
        self.paga = True


@dataclass
class Cota:
    id: int
    numero: int
    cliente_id: int
    grupo_id: int
    parcelas: List[Parcela]
    status: StatusCota = StatusCota.ATIVA
    lance_ofertado: float = 0.0

    def parcelas_pagas(self):
        return [p for p in self.parcelas if p.paga]

    def total_pago(self):
        return sum(p.valor for p in self.parcelas if p.paga)


class SistemaConsorcio:

    def __init__(self):

        self.clientes: Dict[int, Cliente] = {}
        self.veiculos: Dict[int, Veiculo] = {}
        self.grupos: Dict[int, Grupo] = {}
        self.cotas: Dict[int, Cota] = {}

        self.id_cliente = 1
        self.id_veiculo = 1
        self.id_grupo = 1
        self.id_cota = 1

    # CLIENTES

    def cadastrar_cliente(self, nome, cpf, telefone, email):

        cliente = Cliente(
            self.id_cliente,
            nome,
            cpf,
            telefone,
            email
        )

        self.clientes[self.id_cliente] = cliente

        self.id_cliente += 1

        return cliente

    def listar_clientes(self):
        return list(self.clientes.values())

    # VEÍCULOS

    def cadastrar_veiculo(self, marca, modelo, ano, valor):

        veiculo = Veiculo(
            self.id_veiculo,
            marca,
            modelo,
            ano,
            valor
        )

        self.veiculos[self.id_veiculo] = veiculo

        self.id_veiculo += 1

        return veiculo

    def listar_veiculos(self):
        return list(self.veiculos.values())

    # GRUPOS

    def criar_grupo(
        self,
        nome,
        veiculo_id,
        quantidade_cotas,
        prazo_meses,
        taxa
    ):

        veiculo = self.veiculos[veiculo_id]

        valor_credito = veiculo.valor + (
            veiculo.valor * (taxa / 100)
        )

        grupo = Grupo(
            self.id_grupo,
            nome,
            prazo_meses,
            valor_credito,
            quantidade_cotas,
            taxa
        )

        self.grupos[self.id_grupo] = grupo

        self.id_grupo += 1

        return grupo

    def listar_grupos(self):
        return list(self.grupos.values())

    # COTAS

    def vender_cota(self, cliente_id, grupo_id):

        grupo = self.grupos[grupo_id]

        valor_parcela = grupo.valor_credito / grupo.parcelas

        parcelas = []

        for i in range(grupo.parcelas):

            parcela = Parcela(
                numero=i + 1,
                valor=valor_parcela
            )

            parcelas.append(parcela)

        cota = Cota(
            id=self.id_cota,
            numero=self.id_cota,
            cliente_id=cliente_id,
            grupo_id=grupo_id,
            parcelas=parcelas
        )

        self.cotas[self.id_cota] = cota

        self.id_cota += 1

        return cota

    def listar_cotas(self):
        return list(self.cotas.values())

    # ESTATÍSTICAS

    def estatisticas_sistema(self):

        total_arrecadado = sum(
            c.total_pago()
            for c in self.cotas.values()
        )

        return {
            "clientes": len(self.clientes),
            "veiculos": len(self.veiculos),
            "grupos": len(self.grupos),
            "cotas": len(self.cotas),
            "arrecadado": formatar_moeda(total_arrecadado)
        }
    